"""Build the notebook from the Python script so both always match.

Usage:  python build_notebook.py username_beam_ai.py
Writes username_beam_ai.ipynb next to it. Cells are split on "# %%" lines;
"# %% [markdown]" cells become markdown.
"""
import sys
from pathlib import Path

import nbformat


def build(script_path):
    script_path = Path(script_path)
    cells = []
    kind, lines = None, []

    def flush():
        text = "\n".join(lines).strip("\n")
        if kind == "markdown":
            text = "\n".join(line[2:] if line.startswith("# ") else line.lstrip("#")
                             for line in text.splitlines())
            cells.append(nbformat.v4.new_markdown_cell(text))
        elif kind == "code" and text.strip():
            cells.append(nbformat.v4.new_code_cell(text))

    for line in script_path.read_text(encoding="utf-8").splitlines():
        if line.startswith("# %%"):
            flush()
            kind = "markdown" if "[markdown]" in line else "code"
            lines = []
        else:
            lines.append(line)
    flush()

    notebook = nbformat.v4.new_notebook(cells=cells)
    notebook.metadata["kernelspec"] = {"name": "python3", "display_name": "Python 3", "language": "python"}
    out_path = script_path.with_suffix(".ipynb")
    nbformat.write(notebook, out_path)
    print(f"Wrote {out_path} ({len(cells)} cells)")


if __name__ == "__main__":
    build(sys.argv[1] if len(sys.argv) > 1 else "username_beam_ai.py")
