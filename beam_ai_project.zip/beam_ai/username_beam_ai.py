# %% [markdown]
# # VIP Individual Project Part 2: Beam Design and AI Model Comparison
#
# Three methods search for the lightest feasible steel beam using the same
# black-box evaluator, `evaluate_beam(width_mm, height_mm)` from `beam_model.py`:
#
# 1. A conventional numerical optimizer (`scipy.optimize.minimize`, SLSQP).
# 2. An AI design agent using **Llama 3.2 1B** through Ollama.
# 3. The same AI design agent using a **GPT model** through the OpenAI API.
#
# The agent loop is the same decision loop as Part 1:
# **observe** the history, **select** the next design (the model proposes it),
# **evaluate** it with the black box, then update the history.
#
# Every attempted design is written to `<username>_beam_ai.csv`.
#
# Note on units: the assignment sheet says "supply both dimensions in meters",
# but the provided `evaluate_beam` takes **millimeters** (its bounds are 20-100 mm
# and 40-120 mm, and it rejects 0.05 or 0.08). This project uses millimeters.

# %% [markdown]
# ## 1. Setup and configuration
# Change `USERNAME` to your Purdue username. Models and settings are set here so
# the experiment is reproducible. API keys are read from the environment
# (or a local `.env` file) and are never written to any output.

# %%
import csv
import json
import math
import os
import platform
import re
import sys
import time
from datetime import datetime
from pathlib import Path

import matplotlib

IN_NOTEBOOK = "ipykernel" in sys.modules
if not IN_NOTEBOOK:
    matplotlib.use("Agg")  # script mode: save figures to files only

import matplotlib.pyplot as plt
import numpy as np
import requests
import scipy
from scipy.optimize import minimize

from beam_model import evaluate_beam  # the common black box (do not modify)

try:  # optional: load OPENAI_API_KEY from a local .env file (never committed)
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass

# ---- Experiment settings ---------------------------------------------------
USERNAME = "username"  # <-- replace with your Purdue username

START_WIDTH_MM = 50.0
START_HEIGHT_MM = 80.0
N_RUNS_PER_MODEL = 2
N_PROPOSALS_PER_RUN = 11

# Problem statement from the assignment sheet (used for the prompt and checks)
WIDTH_MIN_MM, WIDTH_MAX_MM = 20.0, 100.0
HEIGHT_MIN_MM, HEIGHT_MAX_MM = 40.0, 120.0
DEFLECTION_LIMIT_MM = 1.0
STRESS_LIMIT_MPA = 120.0

# ---- AI model settings -----------------------------------------------------
OLLAMA_MODEL = "llama3.2:1b"
OLLAMA_URL = os.environ.get("OLLAMA_HOST", "http://localhost:11434").rstrip("/")
OLLAMA_TEMPERATURE = 0.8  # Ollama's default, written out explicitly
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-5-mini")
# GPT-5 family models only accept their default temperature (1.0). For an older
# model such as gpt-4o-mini you can set a number here, e.g. 0.8.
OPENAI_TEMPERATURE = None
USE_JSON_MODE = True  # ask both services for JSON output (same rule for both)
REQUEST_TIMEOUT_S = 180

# ---- Output files ----------------------------------------------------------
CSV_PATH = Path(f"{USERNAME}_beam_ai.csv")
SUMMARY_PATH = Path("results_summary.csv")
RUN_INFO_PATH = Path("run_info.json")
FIG_DIR = Path("figures")
FIG_DIR.mkdir(exist_ok=True)

CSV_COLUMNS = [
    "method", "model", "model_id_reported", "run", "iteration",
    "width_mm", "height_mm", "mass_kg", "max_deflection_mm",
    "max_von_mises_stress_MPa", "feasible", "response_status", "status_detail",
    "evaluated", "repeat_design", "best_feasible_mass_so_far_kg",
    "elapsed_s", "raw_reply",
]

ALL_ROWS = []  # every attempted design from every method goes here
RUN_INFO = {
    "username": USERNAME,
    "timestamp": datetime.now().isoformat(timespec="seconds"),
    "python": platform.python_version(),
    "numpy": np.__version__,
    "scipy": scipy.__version__,
    "matplotlib": matplotlib.__version__,
    "platform": platform.platform(),
    "settings": {
        "start_design_mm": [START_WIDTH_MM, START_HEIGHT_MM],
        "runs_per_model": N_RUNS_PER_MODEL,
        "proposals_per_run": N_PROPOSALS_PER_RUN,
        "ollama_model": OLLAMA_MODEL,
        "ollama_temperature": OLLAMA_TEMPERATURE,
        "ollama_seed": "run number (1, 2)",
        "openai_model": OPENAI_MODEL,
        "openai_temperature": OPENAI_TEMPERATURE or "model default",
        "json_mode": USE_JSON_MODE,
    },
    "models": {},
    "runs": [],
}


def show(fig):
    """Display a figure in the notebook; in a script, just free it."""
    if IN_NOTEBOOK:
        plt.show()
    else:
        plt.close(fig)


def make_row(**values):
    """Build one CSV row with every column present."""
    row = {column: "" for column in CSV_COLUMNS}
    row.update(values)
    return row


# %% [markdown]
# ## 2. Task 1: evaluate the common starting design
# Expected: about 31.4 kg, 0.488 mm deflection, 46.9 MPa stress, feasible.

# %%
start_result = evaluate_beam(START_WIDTH_MM, START_HEIGHT_MM)
print(start_result)
print(
    f"Start design {START_WIDTH_MM:g} x {START_HEIGHT_MM:g} mm: "
    f"mass = {start_result['mass_kg']:.2f} kg, "
    f"deflection = {start_result['max_deflection_mm']:.3f} mm, "
    f"stress = {start_result['max_von_mises_stress_MPa']:.1f} MPa, "
    f"feasible = {start_result['feasible']}"
)

# %% [markdown]
# ## 3. Task 2: conventional numerical optimizer
# SLSQP minimizes mass with the two constraints written as `g(x) >= 0`:
#
# * `1 - deflection / 1.0 mm >= 0`
# * `1 - stress / 120 MPa >= 0`
#
# Every objective and constraint value comes from `evaluate_beam`. A small cache
# means a design the optimizer asks about more than once is evaluated only once,
# so the evaluation count is the true number of black-box calls.

# %%
def run_optimizer():
    rows = []
    cache = {}
    best_mass = math.inf
    t_start = time.perf_counter()

    def evaluate(x):
        nonlocal best_mass
        width, height = float(x[0]), float(x[1])
        key = (width, height)
        if key in cache:
            return cache[key]
        try:
            result = evaluate_beam(width, height)
            status, detail = "evaluated", ""
        except ValueError as error:  # should not happen with bounds set
            result, status, detail = None, "evaluator_error", str(error)
        cache[key] = result
        if result and result["feasible"]:
            best_mass = min(best_mass, result["mass_kg"])
        rows.append(make_row(
            method="numerical_optimizer",
            model="scipy.optimize.minimize (SLSQP)",
            model_id_reported=f"scipy {scipy.__version__}",
            run=1,
            iteration=len(rows),
            width_mm=width,
            height_mm=height,
            mass_kg=result["mass_kg"] if result else "",
            max_deflection_mm=result["max_deflection_mm"] if result else "",
            max_von_mises_stress_MPa=result["max_von_mises_stress_MPa"] if result else "",
            feasible=result["feasible"] if result else "",
            response_status=status,
            status_detail=detail,
            evaluated=result is not None,
            repeat_design=False,
            best_feasible_mass_so_far_kg=best_mass if best_mass < math.inf else "",
            elapsed_s=round(time.perf_counter() - t_start, 4),
        ))
        return result

    def mass(x):
        result = evaluate(x)
        return result["mass_kg"] if result else 1e6

    def deflection_margin(x):
        result = evaluate(x)
        return 1.0 - result["max_deflection_mm"] / DEFLECTION_LIMIT_MM if result else -1.0

    def stress_margin(x):
        result = evaluate(x)
        return 1.0 - result["max_von_mises_stress_MPa"] / STRESS_LIMIT_MPA if result else -1.0

    opt = minimize(
        mass,
        x0=[START_WIDTH_MM, START_HEIGHT_MM],
        method="SLSQP",
        bounds=[(WIDTH_MIN_MM, WIDTH_MAX_MM), (HEIGHT_MIN_MM, HEIGHT_MAX_MM)],
        constraints=[
            {"type": "ineq", "fun": deflection_margin},
            {"type": "ineq", "fun": stress_margin},
        ],
        options={"ftol": 1e-9, "maxiter": 200},
    )
    elapsed = time.perf_counter() - t_start
    final = evaluate(opt.x)  # cached, so this does not add a call
    info = {
        "method": "numerical_optimizer",
        "model": "scipy.optimize.minimize (SLSQP)",
        "run": 1,
        "success": bool(opt.success),
        "message": str(opt.message),
        "iterations": int(opt.nit),
        "scipy_function_calls": int(opt.nfev),
        "unique_evaluator_calls": len(cache),
        "final_width_mm": float(opt.x[0]),
        "final_height_mm": float(opt.x[1]),
        "final_mass_kg": final["mass_kg"],
        "final_feasible_by_evaluator": bool(final["feasible"]),
        "elapsed_s": elapsed,
    }
    return rows, info


optimizer_rows, optimizer_info = run_optimizer()
ALL_ROWS.extend(optimizer_rows)
RUN_INFO["runs"].append(optimizer_info)

print(f"Converged: {optimizer_info['success']}  ({optimizer_info['message']})")
print(f"SLSQP iterations: {optimizer_info['iterations']}, "
      f"evaluator calls: {optimizer_info['unique_evaluator_calls']}, "
      f"time: {optimizer_info['elapsed_s']:.3f} s")
print(f"Final design: width = {optimizer_info['final_width_mm']:.3f} mm, "
      f"height = {optimizer_info['final_height_mm']:.3f} mm, "
      f"mass = {optimizer_info['final_mass_kg']:.3f} kg, "
      f"feasible by evaluator = {optimizer_info['final_feasible_by_evaluator']}")

# SLSQP stops right on the deflection limit, so its final point can be
# infeasible by a rounding-level amount (e.g. 1.000000000000001 mm). The
# evaluator's yes/no is the rule, so the reported result is the best design the
# evaluator actually marked feasible.
feasible_opt = [r for r in optimizer_rows if r["feasible"] is True]
best_opt = min(feasible_opt, key=lambda r: r["mass_kg"])
final_row = [r for r in optimizer_rows if (r["width_mm"], r["height_mm"]) ==
             (optimizer_info["final_width_mm"], optimizer_info["final_height_mm"])][0]
print(f"Final point deflection = {final_row['max_deflection_mm']:.15f} mm")
print(f"Best feasible design evaluated: width = {best_opt['width_mm']:.4f} mm, "
      f"height = {best_opt['height_mm']:.4f} mm, mass = {best_opt['mass_kg']:.4f} kg "
      f"(evaluation #{best_opt['iteration']})")

# %% [markdown]
# ## 4. Task 3: the AI design agent
#
# **Prompt.** Each call sends the same system message plus one user message
# with the objective, bounds, constraints, proposals remaining, and the full
# history of results (including invalid replies). The equations are not given;
# the model only sees black-box results.
#
# **Validation rule (identical for both models).** A reply is valid only if:
# 1. it contains a JSON object (the whole reply, or the first `{...}` block in it),
# 2. the object has the keys `width_mm` and `height_mm`,
# 3. both values are JSON numbers (not strings, not true/false) and finite,
# 4. both values are inside the bounds.
#
# An invalid reply is recorded as a failure. It uses up a proposal but is not
# evaluated. Values are never clipped, rounded, or replaced.

# %%
SYSTEM_PROMPT = (
    "You are an engineering design agent. You choose beam dimensions to test. "
    "A black-box analysis evaluates each design you propose. "
    "Always reply with only a JSON object and no other text."
)


def format_history(history):
    lines = ["#   width_mm  height_mm  mass_kg  deflection_mm  stress_MPa  feasible"]
    for entry in history:
        if entry["evaluated"]:
            lines.append(
                f"{entry['iteration']:<3d} {entry['width_mm']:8.3f}  {entry['height_mm']:9.3f}  "
                f"{entry['mass_kg']:7.3f}  {entry['max_deflection_mm']:13.4f}  "
                f"{entry['max_von_mises_stress_MPa']:10.2f}  "
                f"{'yes' if entry['feasible'] else 'NO'}"
            )
        else:
            lines.append(
                f"{entry['iteration']:<3d} INVALID REPLY, not evaluated "
                f"({entry['response_status']}: {entry['status_detail']})"
            )
    return "\n".join(lines)


def build_user_prompt(history, proposals_left):
    feasible = [e for e in history if e["evaluated"] and e["feasible"]]
    if feasible:
        best = min(feasible, key=lambda e: e["mass_kg"])
        best_text = (f"Best feasible design so far: #{best['iteration']}, width_mm = "
                     f"{best['width_mm']}, height_mm = {best['height_mm']}, "
                     f"mass_kg = {best['mass_kg']:.3f}.")
    else:
        best_text = "No feasible design has been found yet."

    return f"""Design a simply supported rectangular steel beam with a central point load.

Objective: minimize beam mass (kg).

Design variables and bounds (inclusive):
- width_mm: {WIDTH_MIN_MM:g} to {WIDTH_MAX_MM:g}
- height_mm: {HEIGHT_MIN_MM:g} to {HEIGHT_MAX_MM:g}

Constraints (a design is feasible only if both hold):
- maximum midspan deflection <= {DEFLECTION_LIMIT_MM:g} mm
- maximum von Mises stress <= {STRESS_LIMIT_MPA:g} MPa

Results of previous evaluations (oldest first):
{format_history(history)}

{best_text}
Proposals remaining, including this one: {proposals_left}.

Use these results to propose ONE new design that you expect to be feasible
and lighter than the best feasible design so far.
Reply with only this JSON object, using numbers:
{{"width_mm": <number>, "height_mm": <number>}}"""


def validate_reply(text):
    """Apply the validation rule. Returns (width, height, status, detail)."""
    if text is None or not text.strip():
        return None, None, "empty_reply", "reply was empty"
    text = text.strip()
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*?\}", text, re.DOTALL)
        if not match:
            return None, None, "no_json", "no JSON object found"
        try:
            data = json.loads(match.group(0))
        except json.JSONDecodeError:
            return None, None, "bad_json", "JSON object could not be parsed"
    if not isinstance(data, dict):
        return None, None, "bad_json", "JSON was not an object"
    if "width_mm" not in data or "height_mm" not in data:
        return None, None, "missing_keys", f"keys found: {sorted(data)}"

    width, height = data["width_mm"], data["height_mm"]
    for name, value in (("width_mm", width), ("height_mm", height)):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return None, None, "non_numeric", f"{name} = {value!r}"
        if not math.isfinite(value):
            return None, None, "non_finite", f"{name} = {value!r}"

    problems = []
    if not WIDTH_MIN_MM <= width <= WIDTH_MAX_MM:
        problems.append(f"width_mm = {width} outside {WIDTH_MIN_MM:g}-{WIDTH_MAX_MM:g}")
    if not HEIGHT_MIN_MM <= height <= HEIGHT_MAX_MM:
        problems.append(f"height_mm = {height} outside {HEIGHT_MIN_MM:g}-{HEIGHT_MAX_MM:g}")
    if problems:
        return float(width), float(height), "out_of_bounds", "; ".join(problems)
    return float(width), float(height), "valid", ""


# %% [markdown]
# ### Model clients
# Both clients take the same two messages and return `(reply_text, model_id)`.
# The model id is what the service reports, so the exact model is on record.

# %%
class OllamaClient:
    label = "Llama 3.2 1B (Ollama)"

    def __init__(self, model, seed):
        self.model = model
        self.seed = seed

    def chat(self, system_text, user_text):
        body = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_text},
                {"role": "user", "content": user_text},
            ],
            "stream": False,
            "options": {"temperature": OLLAMA_TEMPERATURE, "seed": self.seed},
        }
        if USE_JSON_MODE:
            body["format"] = "json"
        response = requests.post(f"{OLLAMA_URL}/api/chat", json=body, timeout=REQUEST_TIMEOUT_S)
        response.raise_for_status()
        data = response.json()
        return data["message"]["content"], data.get("model", self.model)


class OpenAIClient:
    label = "GPT (OpenAI API)"

    def __init__(self, model, seed=None):
        from openai import OpenAI

        self.client = OpenAI(timeout=REQUEST_TIMEOUT_S)  # reads OPENAI_API_KEY
        self.model = model

    def chat(self, system_text, user_text):
        kwargs = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_text},
                {"role": "user", "content": user_text},
            ],
        }
        if OPENAI_TEMPERATURE is not None:
            kwargs["temperature"] = OPENAI_TEMPERATURE
        if USE_JSON_MODE:
            kwargs["response_format"] = {"type": "json_object"}
        response = self.client.chat.completions.create(**kwargs)
        return response.choices[0].message.content, response.model


def ollama_available():
    """Check Ollama is running and the model is pulled. Returns (ok, note)."""
    try:
        tags = requests.get(f"{OLLAMA_URL}/api/tags", timeout=10).json()
        version = requests.get(f"{OLLAMA_URL}/api/version", timeout=10).json()
    except (requests.RequestException, ValueError) as error:
        return False, f"Ollama not reachable at {OLLAMA_URL}: {error}"
    for entry in tags.get("models", []):
        if entry.get("name") in (OLLAMA_MODEL, f"{OLLAMA_MODEL}:latest"):
            RUN_INFO["models"]["ollama"] = {
                "name": entry["name"],
                "digest": entry.get("digest"),
                "ollama_version": version.get("version"),
            }
            return True, f"{entry['name']} digest {entry.get('digest', '')[:12]}"
    return False, f"model {OLLAMA_MODEL} not pulled (run: ollama pull {OLLAMA_MODEL})"


def openai_available():
    try:
        import openai
    except ImportError:
        return False, "openai package not installed"
    if not os.environ.get("OPENAI_API_KEY"):
        return False, "OPENAI_API_KEY is not set"
    RUN_INFO["models"]["openai"] = {"requested": OPENAI_MODEL, "openai_package": openai.__version__}
    return True, OPENAI_MODEL


# %% [markdown]
# ### The agent loop
# Observe (history) -> select (model proposes) -> validate -> evaluate -> update.

# %%
def run_agent(client, model_name, run_id):
    rows = []
    history = []
    seen = set()
    best_mass = math.inf
    model_id_seen = ""
    t_start = time.perf_counter()

    def record(iteration, width, height, result, status, detail, reply, model_id):
        nonlocal best_mass
        evaluated = result is not None
        repeat = evaluated and (width, height) in seen
        if evaluated:
            seen.add((width, height))
            if result["feasible"]:
                best_mass = min(best_mass, result["mass_kg"])
        entry = make_row(
            method="ai_agent",
            model=model_name,
            model_id_reported=model_id,
            run=run_id,
            iteration=iteration,
            width_mm=width if width is not None else "",
            height_mm=height if height is not None else "",
            mass_kg=result["mass_kg"] if evaluated else "",
            max_deflection_mm=result["max_deflection_mm"] if evaluated else "",
            max_von_mises_stress_MPa=result["max_von_mises_stress_MPa"] if evaluated else "",
            feasible=result["feasible"] if evaluated else "",
            response_status=status,
            status_detail=detail,
            evaluated=evaluated,
            repeat_design=repeat,
            best_feasible_mass_so_far_kg=best_mass if best_mass < math.inf else "",
            elapsed_s=round(time.perf_counter() - t_start, 3),
            raw_reply=(reply or "").replace("\n", " ").strip()[:500],
        )
        rows.append(entry)
        history.append(entry)
        status_text = (f"mass {result['mass_kg']:.2f} kg, feasible {result['feasible']}"
                       if evaluated else f"{status}: {detail}")
        print(f"  [{model_name} run {run_id}] #{iteration:2d}  "
              f"w={entry['width_mm']!s:>8} h={entry['height_mm']!s:>8}  {status_text}")

    # Iteration 0: the common starting design (not a model proposal)
    record(0, START_WIDTH_MM, START_HEIGHT_MM,
           evaluate_beam(START_WIDTH_MM, START_HEIGHT_MM), "start", "common starting design", "", "")

    for proposal in range(1, N_PROPOSALS_PER_RUN + 1):
        user_text = build_user_prompt(history, N_PROPOSALS_PER_RUN - proposal + 1)
        try:
            reply, model_id = client.chat(SYSTEM_PROMPT, user_text)
            model_id_seen = model_id or model_id_seen
        except Exception as error:  # service failure counts as a failed proposal
            record(proposal, None, None, None, "api_error",
                   f"{type(error).__name__}: {error}"[:200], "", model_id_seen)
            continue
        width, height, status, detail = validate_reply(reply)
        result = evaluate_beam(width, height) if status == "valid" else None
        record(proposal, width, height, result, status, detail, reply, model_id)

    elapsed = time.perf_counter() - t_start
    RUN_INFO["runs"].append({
        "method": "ai_agent", "model": model_name, "model_id_reported": model_id_seen,
        "run": run_id, "elapsed_s": elapsed,
    })
    return rows


def run_model(client_class, model_name, available_check):
    ok, note = available_check()
    print(f"{client_class.label}: {'available' if ok else 'NOT available'} - {note}")
    if not ok:  # document the failed attempt instead of skipping silently
        ALL_ROWS.append(make_row(
            method="ai_agent", model=model_name, run="", iteration="",
            response_status="service_unavailable", status_detail=note, evaluated=False,
        ))
        return
    for run_id in range(1, N_RUNS_PER_MODEL + 1):
        client = client_class(model_name, seed=run_id)
        ALL_ROWS.extend(run_agent(client, model_name, run_id))


# %% [markdown]
# ## 5. Task 4-5: run Llama 3.2 1B (Ollama), two runs

# %%
run_model(OllamaClient, OLLAMA_MODEL, ollama_available)

# %% [markdown]
# ## 6. Task 4-5: run the GPT model (OpenAI API), two runs

# %%
run_model(OpenAIClient, OPENAI_MODEL, openai_available)

# %% [markdown]
# ## 7. Save the log (one row per attempted design)

# %%
with CSV_PATH.open("w", newline="", encoding="utf-8") as handle:
    writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
    writer.writeheader()
    writer.writerows(ALL_ROWS)
RUN_INFO_PATH.write_text(json.dumps(RUN_INFO, indent=2))
print(f"Wrote {len(ALL_ROWS)} rows to {CSV_PATH} and settings to {RUN_INFO_PATH}")

# %% [markdown]
# ## 8. Results table
# Margins are measured from the limits: deflection margin = 1.0 mm - deflection,
# stress margin = 120 MPa - stress. A design that violates either constraint
# never counts as a result, even if it is lighter.

# %%
def summarize(rows, run_info):
    groups = {}
    for row in rows:
        if row["run"] == "":
            continue
        groups.setdefault((row["method"], row["model"], row["run"]), []).append(row)

    elapsed_lookup = {(r["method"], r["model"], r["run"]): r for r in run_info["runs"]}
    summary = []
    for (method, model, run_id), group in groups.items():
        evaluated = [r for r in group if r["evaluated"] is True]
        feasible = [r for r in evaluated if r["feasible"] is True]
        proposals = [r for r in group if r["response_status"] not in ("start", "evaluated", "evaluator_error")]
        best = min(feasible, key=lambda r: r["mass_kg"]) if feasible else None
        info = elapsed_lookup.get((method, model, run_id), {})
        if method == "numerical_optimizer":
            convergence = f"{'success' if info.get('success') else 'FAILED'}: {info.get('message', '')}"
        else:
            convergence = "n/a"
        summary.append({
            "method": method,
            "model": model,
            "run": run_id,
            "best_feasible_mass_kg": round(best["mass_kg"], 4) if best else "none found",
            "width_mm": round(best["width_mm"], 4) if best else "",
            "height_mm": round(best["height_mm"], 4) if best else "",
            "deflection_mm": round(best["max_deflection_mm"], 4) if best else "",
            "deflection_margin_mm": round(DEFLECTION_LIMIT_MM - best["max_deflection_mm"], 4) if best else "",
            "stress_MPa": round(best["max_von_mises_stress_MPa"], 3) if best else "",
            "stress_margin_MPa": round(STRESS_LIMIT_MPA - best["max_von_mises_stress_MPa"], 3) if best else "",
            "beam_evaluations": len(evaluated),
            "model_proposals": len(proposals),
            "invalid_replies": sum(r["response_status"] not in ("valid", "start", "evaluated") for r in proposals),
            "out_of_bounds": sum(r["response_status"] == "out_of_bounds" for r in group),
            "repeated_designs": sum(r["repeat_design"] is True for r in group),
            "infeasible_evaluations": len(evaluated) - len(feasible),
            "elapsed_s": round(info.get("elapsed_s", float("nan")), 3),
            "convergence": convergence,
        })
    return summary


SUMMARY = summarize(ALL_ROWS, RUN_INFO)
with SUMMARY_PATH.open("w", newline="", encoding="utf-8") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(SUMMARY[0]))
    writer.writeheader()
    writer.writerows(SUMMARY)

header = f"{'method':<20}{'model':<34}{'run':>4}{'best kg':>10}{'w mm':>9}{'h mm':>9}" \
         f"{'defl mgn':>10}{'strs mgn':>10}{'evals':>7}{'invalid':>9}{'time s':>9}"
print(header)
print("-" * len(header))
for s in SUMMARY:
    print(f"{s['method']:<20}{s['model'][:33]:<34}{s['run']!s:>4}{s['best_feasible_mass_kg']!s:>10}"
          f"{s['width_mm']!s:>9}{s['height_mm']!s:>9}{s['deflection_margin_mm']!s:>10}"
          f"{s['stress_margin_MPa']!s:>10}{s['beam_evaluations']:>7}{s['invalid_replies']:>9}"
          f"{s['elapsed_s']:>9}")
print(f"\nOptimizer convergence: {SUMMARY[0]['convergence']}")

# %% [markdown]
# ## 9. Plots
# **Search history:** best feasible mass after each proposal for every AI run,
# with the optimizer's best feasible mass as a reference line.
# **Design space:** feasibility and mass from the black box on a grid, with the
# designs each method tried.

# %%
RUN_COLORS = {1: "#1f5fa8", 2: "#e08a1e"}  # blue and orange
MODEL_STYLES = {OLLAMA_MODEL: "-", OPENAI_MODEL: "--"}

optimizer_best = [s for s in SUMMARY if s["method"] == "numerical_optimizer"][0]
ai_runs = [s for s in SUMMARY if s["method"] == "ai_agent"]

fig, ax = plt.subplots(figsize=(8, 4.8))
for s in ai_runs:
    rows = [r for r in ALL_ROWS if r["method"] == "ai_agent" and r["model"] == s["model"] and r["run"] == s["run"]]
    x = [r["iteration"] for r in rows]
    y = [r["best_feasible_mass_so_far_kg"] if r["best_feasible_mass_so_far_kg"] != "" else np.nan for r in rows]
    ax.step(x, y, where="post", color=RUN_COLORS.get(s["run"], "gray"),
            linestyle=MODEL_STYLES.get(s["model"], ":"), marker="o", markersize=4,
            label=f"{s['model']} run {s['run']}")
if isinstance(optimizer_best["best_feasible_mass_kg"], float):
    ax.axhline(optimizer_best["best_feasible_mass_kg"], color="#2e8b57", linewidth=1.5,
               label=f"SLSQP optimum ({optimizer_best['best_feasible_mass_kg']:.2f} kg)")
ax.set_xlabel("Proposal number (0 = common starting design)")
ax.set_ylabel("Best feasible mass so far (kg)")
ax.set_title("AI agent search history")
ax.set_xticks(range(0, N_PROPOSALS_PER_RUN + 1))
ax.grid(alpha=0.3)
ax.legend(fontsize=8)
fig.tight_layout()
fig.savefig(FIG_DIR / "search_history.png", dpi=200)
show(fig)

# %%
# Design-space map: feasibility and mass on a grid, computed by the black box
widths = np.linspace(WIDTH_MIN_MM, WIDTH_MAX_MM, 161)
heights = np.linspace(HEIGHT_MIN_MM, HEIGHT_MAX_MM, 161)
mass_grid = np.zeros((len(heights), len(widths)))
feasible_grid = np.zeros_like(mass_grid)
for i, h in enumerate(heights):
    for j, w in enumerate(widths):
        result = evaluate_beam(float(w), float(h))
        mass_grid[i, j] = result["mass_kg"]
        feasible_grid[i, j] = result["feasible"]

panels = [("numerical_optimizer", "scipy SLSQP")]
panels += [("ai_agent", s["model"]) for s in ai_runs if s["run"] == 1]
fig, axes = plt.subplots(1, len(panels), figsize=(5.2 * len(panels), 4.6), squeeze=False)
for ax, (method, model) in zip(axes[0], panels):
    ax.contourf(widths, heights, feasible_grid, levels=[-0.5, 0.5, 1.5],
                colors=["#e6e6e6", "#d7e8f7"])
    lines = ax.contour(widths, heights, mass_grid, levels=8, colors="#7a7a7a", linewidths=0.6)
    ax.clabel(lines, fmt="%.0f kg", fontsize=7)
    for run_id in range(1, N_RUNS_PER_MODEL + 1):
        rows = [r for r in ALL_ROWS if r["method"] == method and r["run"] == run_id
                and (method == "numerical_optimizer" or r["model"] == model) and r["evaluated"] is True]
        if not rows:
            continue
        xs = [r["width_mm"] for r in rows]
        ys = [r["height_mm"] for r in rows]
        ax.plot(xs, ys, "-", color=RUN_COLORS[run_id], alpha=0.5, linewidth=1)
        ok = [r for r in rows if r["feasible"]]
        bad = [r for r in rows if not r["feasible"]]
        ax.scatter([r["width_mm"] for r in ok], [r["height_mm"] for r in ok], s=22,
                   color=RUN_COLORS[run_id], label=f"run {run_id} feasible", zorder=3)
        ax.scatter([r["width_mm"] for r in bad], [r["height_mm"] for r in bad], s=30,
                   marker="x", color=RUN_COLORS[run_id], label=f"run {run_id} infeasible", zorder=3)
    ax.scatter([START_WIDTH_MM], [START_HEIGHT_MM], marker="*", s=140, color="black",
               label="start", zorder=4)
    ax.set_xlim(WIDTH_MIN_MM - 2, WIDTH_MAX_MM + 2)  # so points on the bounds stay visible
    ax.set_ylim(HEIGHT_MIN_MM - 2, HEIGHT_MAX_MM + 2)
    ax.set_title(model if method == "ai_agent" else "Numerical optimizer (SLSQP)", fontsize=10)
    ax.set_xlabel("Width (mm)")
    ax.set_ylabel("Height (mm)")
    ax.legend(fontsize=7, loc="upper right")
fig.suptitle("Designs evaluated (blue shading = feasible region from the black box)", fontsize=11)
fig.tight_layout()
fig.savefig(FIG_DIR / "design_space.png", dpi=200)
show(fig)

# %% [markdown]
# ## 10. Observations from the logs
# Facts pulled straight from the CSV to support the discussion: did each run
# improve after the start, repeat designs, leave the bounds, or fail to find a
# feasible design?

# %%
def observations(rows, summary):
    notes = []
    for s in summary:
        if s["method"] != "ai_agent":
            continue
        group = [r for r in rows if r["method"] == "ai_agent" and r["model"] == s["model"] and r["run"] == s["run"]]
        proposals = [r for r in group if r["response_status"] != "start"]
        valid = [r for r in proposals if r["evaluated"] is True]
        improved = []
        for r in valid:
            before = [p for p in group if p["iteration"] < r["iteration"] and p["evaluated"] is True and p["feasible"]]
            best_before = min((p["mass_kg"] for p in before), default=math.inf)
            if r["feasible"] and r["mass_kg"] < best_before:
                improved.append(r["iteration"])
        text = (f"{s['model']} run {s['run']}: {len(valid)} of {len(proposals)} proposals were valid and evaluated; "
                f"{s['infeasible_evaluations']} evaluated designs were infeasible; "
                f"{s['invalid_replies']} invalid replies ({s['out_of_bounds']} out of bounds); "
                f"{s['repeated_designs']} repeated designs. ")
        if improved:
            text += f"New best feasible design at proposals {improved}. "
        else:
            text += "It never improved on the starting design. "
        if s["best_feasible_mass_kg"] == "none found":
            text += "No feasible design found."
        elif isinstance(optimizer_best["best_feasible_mass_kg"], float):
            gap = s["best_feasible_mass_kg"] / optimizer_best["best_feasible_mass_kg"] - 1
            text += f"Best feasible mass is {100 * gap:.1f}% above the optimizer."
        notes.append(text)
    return notes


OBSERVATIONS = observations(ALL_ROWS, SUMMARY)
Path("observations.txt").write_text("\n".join(OBSERVATIONS))
for note in OBSERVATIONS:
    print("-", note)
