# Beam Design and AI Model Comparison

VIP: Agentic AI for Engineering Design, Purdue ME, Fall 2026. Individual Project Part 2.

Three methods search for the lightest feasible steel beam (simply supported, central
10 kN load, 1 m span). All of them call the same black box, `evaluate_beam(width_mm, height_mm)`
in the provided `beam_model.py`:

| Method | What picks the next design |
|---|---|
| Numerical optimizer | `scipy.optimize.minimize`, SLSQP |
| AI agent, Llama | `llama3.2:1b` through Ollama |
| AI agent, GPT | `gpt-5-mini` through the OpenAI API (change with `OPENAI_MODEL`) |

Objective: minimize mass. Constraints: deflection ≤ 1.0 mm, von Mises stress ≤ 120 MPa.
Bounds: width 20 to 100 mm, height 40 to 120 mm. Note: `evaluate_beam` takes millimeters.

## Files

| File | Purpose |
|---|---|
| `beam_model.py` | Provided evaluator. Not modified. |
| `username_beam_ai.py` | The full experiment as a runnable script. |
| `username_beam_ai.ipynb` | Same code as a notebook (built from the script). |
| `username_beam_ai.csv` | One row per attempted design (created by a run). |
| `make_report.py` | Builds `username_beam_ai.pdf` from the run outputs and `report_text.md`. |
| `report_text.md` | Name, GitHub URL, discussion, and limitations for the report. |
| `build_notebook.py` | Rebuilds the notebook from the script after edits. |
| `results_summary.csv`, `run_info.json`, `observations.txt`, `figures/` | Created by a run. |

## Setup

1. Python 3.10 or newer.
2. Create a virtual environment and install packages:
   ```bash
   python -m venv .venv
   source .venv/bin/activate        # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   ```
3. Install [Ollama](https://ollama.com), start it, and pull the model:
   ```bash
   ollama pull llama3.2:1b
   ```
4. Put your OpenAI key in a `.env` file in this folder (copy `.env.example`). `.env` is in `.gitignore`.
   ```
   OPENAI_API_KEY=sk-...
   OPENAI_MODEL=gpt-5-mini
   ```

## Run

```bash
python username_beam_ai.py      # or: jupyter notebook username_beam_ai.ipynb, then Run All
python make_report.py           # after filling in report_text.md
```

The run takes a few minutes, mostly waiting on the models. If Ollama or the OpenAI key is
not available, that model is skipped and the CSV gets a `service_unavailable` row saying why.

## How the AI agent works

Each of the 11 proposals in a run:

1. **Observe.** Build a prompt with the objective, bounds, constraints, proposals left, and the
   full history of results (invalid replies included, with the reason).
2. **Select.** The model replies with `{"width_mm": <number>, "height_mm": <number>}`.
3. **Validate.** Same rule for both models: JSON object, both keys, real numbers (not strings),
   inside the bounds. Anything else is logged as a failure and is not evaluated. Values are
   never clipped or fixed.
4. **Evaluate.** Call `evaluate_beam`, log the row, add it to the history.

Proposal 0 is always the common start design (50 x 80 mm). No numerical optimizer is used
inside the agent.

## Reproducibility

Settings are at the top of `username_beam_ai.py` and are saved in `run_info.json` with
package versions, the Ollama model digest, and the model id each service reported.

- Llama: temperature 0.8, seed = run number, JSON format mode.
- GPT: model default temperature (the GPT-5 family only allows 1.0), JSON response format.

Never commit `.env`, API keys, or `.venv/`.
