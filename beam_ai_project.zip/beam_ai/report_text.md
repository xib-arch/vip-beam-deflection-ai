Name: Xavier Blanchard
GitHub: https://github.com/YOUR-ACCOUNT/YOUR-REPO

## Method summary
All three methods started from the common design (50 mm x 80 mm) and used the provided evaluate_beam function for every evaluation. The numerical optimizer was scipy.optimize.minimize with SLSQP, with both constraints written as normalized inequalities and the design-variable bounds passed directly. The AI agent ran the same observe, propose, validate, evaluate loop for both models. Each call gave the model the objective, bounds, constraints, and the full history of results, and asked for one JSON reply with width_mm and height_mm. Replies that were not valid JSON numbers inside the bounds were logged as failures and not evaluated. No proposed value was clipped or changed. Each model ran twice, with 11 proposals per run.

## Comparison and discussion
TODO: Write this in your own words after you run the experiment. Use the results table, the plots, and the auto-generated observations above. Questions to answer:
- Which method found the lightest feasible beam, and how close did each AI run get to the optimizer?
- Did each model use the feedback? Look for runs where the mass dropped after an infeasible result, or where the model kept guessing without a pattern.
- Where did a model repeat a design, leave the bounds, send a bad reply, or never find a feasible design?
- How different were the two runs of the same model, and why might that be?
- How do evaluations and elapsed time compare between the optimizer and the agents?

## Limitations
The evaluator is a static beam-theory model. It assumes small deflections, linear elastic steel, ideal supports, and an ideal central point load. It leaves out self-weight, local contact stress at the load and supports, and impact behavior, so it is not a bumper crash model.
Each AI model ran only twice, so the run-to-run variation is a small sample. Results also depend on the prompt wording, the JSON output mode, and the sampling settings. The GPT-5 family only allows its default temperature, so the two models did not use identical sampling settings.
Elapsed time for the agents is mostly model response time (local hardware for Llama, network and server time for GPT). It is not a direct measure of search efficiency next to the optimizer.
SLSQP finished exactly on the deflection limit. Because of floating-point rounding, its final point can read as slightly over 1.0 mm, so the reported optimizer result is the best design the evaluator actually marked feasible. The optimizer evaluation count includes finite-difference gradient steps.
