"""Build the PDF report from the experiment outputs.

Run this AFTER username_beam_ai.py (or the notebook) has finished:
    python make_report.py

Inputs:  results_summary.csv, run_info.json, observations.txt, figures/*.png,
         report_text.md (your name, GitHub URL, discussion, limitations)
Output:  <username>_beam_ai.pdf
"""
import csv
import json
import re
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

BLUE = colors.HexColor("#1f5fa8")
LIGHT = colors.HexColor("#eef4fb")


def read_report_text(path):
    header, sections, current = {}, {}, None
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.startswith("## "):
            current = line[3:].strip()
            sections[current] = []
        elif current is None and ":" in line:
            key, value = line.split(":", 1)
            header[key.strip().lower()] = value.strip()
        elif current is not None:
            sections[current].append(line)
    return header, {k: "\n".join(v).strip() for k, v in sections.items()}


def paragraphs(text, style, bullet_style):
    out = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        line = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        if line.startswith("- "):
            out.append(Paragraph(line[2:], bullet_style, bulletText="•"))
        else:
            out.append(Paragraph(line, style))
    return out


def main():
    header, sections = read_report_text("report_text.md")
    summary = list(csv.DictReader(open("results_summary.csv", encoding="utf-8")))
    run_info = json.loads(Path("run_info.json").read_text())
    username = run_info.get("username", "username")  # set by USERNAME in the experiment script
    observations = Path("observations.txt").read_text().splitlines() if Path("observations.txt").exists() else []

    problems = []
    if any("TODO" in text for text in sections.values()):
        problems.append("report_text.md still has a TODO section")
    if "YOUR-ACCOUNT" in header.get("github", ""):
        problems.append("GitHub URL is still the placeholder")
    if username == "username":
        problems.append("USERNAME in the experiment script is still 'username'")

    styles = getSampleStyleSheet()
    body = ParagraphStyle("body", parent=styles["BodyText"], fontSize=9.5, leading=12.5, spaceAfter=5)
    bullet = ParagraphStyle("bullet", parent=body, leftIndent=12, bulletIndent=2, spaceAfter=2)
    h1 = ParagraphStyle("h1", parent=styles["Title"], fontSize=15, textColor=BLUE, spaceAfter=4)
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], fontSize=11.5, textColor=BLUE, spaceBefore=8, spaceAfter=4)
    small = ParagraphStyle("small", parent=body, fontSize=8, leading=10)
    cell = ParagraphStyle("cell", parent=body, fontSize=7.5, leading=9, spaceAfter=0)

    story = [
        Paragraph("Beam Design and AI Model Comparison", h1),
        Paragraph(f"VIP: Agentic AI for Engineering Design, Individual Project Part 2. "
                  f"{header.get('name', '')} ({username})", body),
        Paragraph(f"GitHub repository: {header.get('github', '')}", body),
    ]

    if "Method summary" in sections:
        story += [Paragraph("Method", h2)] + paragraphs(sections["Method summary"], body, bullet)

    # Software and model identifiers
    settings = run_info["settings"]
    models = run_info.get("models", {})
    agent_ids = sorted({r.get("model_id_reported", "") for r in run_info["runs"]
                        if r["method"] == "ai_agent" and r.get("model_id_reported")})
    ollama = models.get("ollama", {})
    id_lines = [
        f"Python {run_info['python']}, NumPy {run_info['numpy']}, SciPy {run_info['scipy']}, "
        f"Matplotlib {run_info['matplotlib']}. Run on {run_info['timestamp']}.",
        f"Llama: {ollama.get('name', settings['ollama_model'])} via Ollama {ollama.get('ollama_version', '')}, "
        f"digest {str(ollama.get('digest', 'n/a'))[:12]}, temperature {settings['ollama_temperature']}, "
        f"seed = run number.",
        f"GPT: requested {settings['openai_model']}, temperature {settings['openai_temperature']}. "
        f"Model ids reported by the services: {', '.join(agent_ids) or 'none (no successful calls)'}.",
        f"JSON output mode: {settings['json_mode']}. Start design {settings['start_design_mm']} mm, "
        f"{settings['runs_per_model']} runs per model, {settings['proposals_per_run']} proposals per run.",
    ]
    story += [Paragraph("Software and model identifiers", h2)] + [Paragraph(t, small) for t in id_lines]

    # Results table
    story.append(Paragraph("Results", h2))
    head = ["Method / model", "Run", "Best feasible mass (kg)", "Width (mm)", "Height (mm)",
            "Deflection margin (mm)", "Stress margin (MPa)", "Beam evals", "Invalid replies", "Time (s)"]
    data = [[Paragraph(f"<b>{h}</b>", cell) for h in head]]
    for s in summary:
        name = "SLSQP optimizer" if s["method"] == "numerical_optimizer" else s["model"]
        data.append([Paragraph(name, cell), s["run"], s["best_feasible_mass_kg"], s["width_mm"],
                     s["height_mm"], s["deflection_margin_mm"], s["stress_margin_MPa"],
                     s["beam_evaluations"], s["invalid_replies"], s["elapsed_s"]])
    table = Table(data, repeatRows=1, colWidths=[1.15 * inch, 0.32 * inch] + [0.69 * inch] * 8)
    table.setStyle(TableStyle([
        ("FONTSIZE", (0, 1), (-1, -1), 7.5),
        ("BACKGROUND", (0, 0), (-1, 0), LIGHT),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#9fb6cf")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (1, 1), (-1, -1), "CENTER"),
    ]))
    story.append(table)
    optimizer = next((r for r in run_info["runs"] if r["method"] == "numerical_optimizer"), None)
    if optimizer:
        story.append(Spacer(1, 4))
        story.append(Paragraph(
            f"Optimizer convergence: {'converged' if optimizer['success'] else 'did NOT converge'} "
            f"({optimizer['message']}) after {optimizer['iterations']} SLSQP iterations and "
            f"{optimizer['unique_evaluator_calls']} evaluator calls. Final point "
            f"{optimizer['final_width_mm']:.3f} x {optimizer['final_height_mm']:.3f} mm, "
            f"{optimizer['final_mass_kg']:.4f} kg, feasible by evaluator: "
            f"{optimizer['final_feasible_by_evaluator']}. Margins are limit minus value; "
            f"a margin of 0.0 means the design sits on that limit.", small))
    unavailable = [r for r in csv.DictReader(open(f"{username}_beam_ai.csv", encoding="utf-8"))
                   if r["response_status"] == "service_unavailable"] if Path(f"{username}_beam_ai.csv").exists() else []
    for r in unavailable:
        story.append(Paragraph(f"Not run: {r['model']} ({r['status_detail']})", small))

    for name in ("search_history.png", "design_space.png"):
        path = Path("figures") / name
        if path.exists():
            width = 6.0 * inch if name == "search_history.png" else 7.0 * inch
            image = Image(str(path))
            image.drawHeight = width * image.imageHeight / image.imageWidth
            image.drawWidth = width
            story += [Spacer(1, 6), image]

    if observations:
        story.append(Paragraph("Observations from the logs", h2))
        story += [Paragraph(o, bullet, bulletText="•") for o in observations]

    for title in ("Comparison and discussion", "Limitations"):
        if title in sections:
            story += [Paragraph(title, h2)] + paragraphs(sections[title], body, bullet)

    out = Path(f"{username}_beam_ai.pdf")
    SimpleDocTemplate(str(out), pagesize=letter, leftMargin=0.7 * inch, rightMargin=0.7 * inch,
                      topMargin=0.6 * inch, bottomMargin=0.6 * inch, title="Beam Design and AI Model Comparison").build(story)
    print(f"Wrote {out}")
    for p in problems:
        print(f"WARNING: {p}. Fix it and run again before submitting.")


if __name__ == "__main__":
    main()
